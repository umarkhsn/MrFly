function startGame() {
    let playerName = document.getElementById("player-name").value;
    if (playerName.trim() === "") {
        alert("Please enter your name!");
        return;
    }
    document.getElementById("welcome-screen").style.display = "none";
    document.getElementById("game-container").style.display = "block";
    initGame();
}

function initGame() {
    let canvas = document.getElementById("gameCanvas");
    let ctx = canvas.getContext("2d");
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    ctx.fillStyle = "skyblue";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}
